import pandas as pd

f = open('list_data.txt', 'r')
data = f.readlines()
input_var = input("enter a word: ")
df = pd.DataFrame(data)
dict_words = dict(zip(range(len(df)), ((df[0]))))

list_data = []
index_list = []


def func(dict_words, input_var):
    try:
        for i in range(len(dict_words)):
            if input_var == dict_words[i].replace('\n', ''):
                x = dict_words[i].replace('\n', '')

                return print(x, ",word present in dictionary")

        for i in range(len(dict_words)):

            if dict_words[i][0] == input_var[0]:

                x = (dict_words[i]).replace('\n', '')

                list_data.append(x)
                index_list.append(i+1)

        new_df = pd.DataFrame(list_data, index_list)
        new_df.columns = ['words']
        index_1 = new_df.index

        for i in range(len(new_df)):
            if new_df['words'][index_1[0]+i][0] == input_var[0]:
                b1 = new_df.query(f"words.str.contains('{input_var}')")
                index_2 = b1.index
                word_list = []
                for j in index_2:
                    word_list.append(dict_words[j-1].replace('\n', ''))
                return print("relevent words: ", (word_list))
        if len(word_list) == 0:
            return print("no relevent words in dictionary")

    except Exception as e:
        print("error",e)


func(dict_words, input_var)


f.close()
